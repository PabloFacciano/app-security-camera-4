﻿Module App

    Private AppConfigSerializer As New Xml.Serialization.XmlSerializer(GetType(AppConfig))
    Public CurrentAppConfig As AppConfig

    Public Sub LoadAppConfig()
        ' Load default app config
        If (String.IsNullOrWhiteSpace(My.Settings.Config)) Then
            CurrentAppConfig = AppConfig.DefaultAppConfig()
            Return
        End If
        ' Load current app config
        Dim string_reader As New IO.StringReader(My.Settings.Config)
        CurrentAppConfig = DirectCast(AppConfigSerializer.Deserialize(string_reader), AppConfig)
        string_reader.Close()
    End Sub
    Public Sub SaveAppConfig()
        Dim string_writer As New IO.StringWriter
        AppConfigSerializer.Serialize(string_writer, CurrentAppConfig)
        My.Settings.Config = string_writer.ToString()
        My.Settings.Save()
        string_writer.Close()
    End Sub


    Public Sub DeleteCameraByIndex(index As Integer)
        CurrentAppConfig.Cameras.RemoveAt(index)
        SaveAppConfig()
    End Sub
    Public Sub UpsertCameraByIndex(index As Integer, camera As Camera)
        If (index > -1) Then
            CurrentAppConfig.Cameras.RemoveAt(index)
        End If
        CurrentAppConfig.Cameras.Add(camera)

        SaveAppConfig()
    End Sub

    Private WithEvents openForms As New List(Of frmCameraView)
    Public Sub OpenCamera(index As Integer)
        ' No abrir cámara si ya está abierta
        If (CurrentAppConfig.OpenCameras.Contains(index)) Then
            MsgBox("This camera is still open.", MsgBoxStyle.Information, "Open Camera")
            Return
        End If
        ' Guardar camara abierta y guardar para la proxima ejecucion
        CurrentAppConfig.OpenCameras.Add(index)
        SaveAppConfig()
        ' Open the camera view
        Dim frm As New frmCameraView
        frm.Camera = CurrentAppConfig.Cameras.Item(index)
        frm.Tag = index
        frm.Text = frm.Camera.Name & " - Camera"
        frm.Show()
        AddHandler frm.FormClosed, AddressOf CameraFormClosed
        openForms.Add(frm)
    End Sub
    Private Sub CameraFormClosed(form As frmCameraView, e As FormClosedEventArgs)
        CurrentAppConfig.OpenCameras.Remove(form.Tag)
        form.Dispose()
        SaveAppConfig()
    End Sub


    Public Function HTML_CameraWebPage(ip As String, port As String, username As String, password As String) As String

        ' use this to debug iebrowser
        ' %systemroot%\system32\f12\IEChooser.exe

        Dim html As String = ""
        html &= vbNewLine & "<!doctype html>"
        html &= vbNewLine & "<html lang='en'>"
        ' Default HTML Head
        html &= vbNewLine & "<head>"
        html &= vbNewLine & "<meta http-equiv=|X-UA-Compatible| content=|IE=edge| >"
        html &= vbNewLine & "<style>body{background:rgb(30,30,30);}#ocx{width:100vw;height:100vh;background:#f00;}</style>"
        html &= vbNewLine & "<title>Camera</title>"
        html &= vbNewLine & "<meta charset='utf-8'>"
        html &= vbNewLine & "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>"
        html &= vbNewLine & "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        html &= vbNewLine & "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65' crossorigin='anonymous'>"
        html &= vbNewLine & "</head>"
        html &= vbNewLine & "<body>"
        ' javascript: includes ocx
        html &= vbNewLine & "<script>"
        html &= vbNewLine & "document.open();"
        html &= vbNewLine & "document.write(|<object id='ocx' type='application/x-hyplayer' width='100%' height='100%' align='center' valign='middle' border='0'>|);"
        html &= vbNewLine & "document.write(|</object>|);"
        html &= vbNewLine & "document.close();"
        ' javascript: run ocx
        html &= vbNewLine & "var ocx = document.getElementById('ocx');"
        ' html &= vbNewLine & "ocx.SetDeviceInfo('{username}', '{password}', '{ip}', {port});"
        html &= vbNewLine & "ocx.Play(|rtsp://| + encodeURIComponent(|{username}|) + |:| + encodeURIComponent(|{password}|) + |@| + |{ip}| + |:80/live/ch0|);"
        html = html.Replace("{username}", username)
        html = html.Replace("{password}", password)
        html = html.Replace("{ip}", ip)
        html = html.Replace("{port}", port)
        ' end html
        html &= vbNewLine & "</script>"
        html &= vbNewLine & "</body>"
        html &= vbNewLine & "</html>"

        html = html.Replace("|", Chr(34)) ' comillas

        Console.WriteLine("HTML of Camera Webpage:")
        Console.Write(html)
        Return html
    End Function
    Public Function ControlToBitmap(ctrl As Control, clientAreaOnly As Boolean) As Bitmap
        If ctrl Is Nothing Then Return Nothing
        Dim rect As Rectangle

        If clientAreaOnly Then
            rect = ctrl.RectangleToScreen(ctrl.ClientRectangle)
        Else
            rect = If(ctrl.Parent Is Nothing, ctrl.Bounds, ctrl.Parent.RectangleToScreen(ctrl.Bounds))
        End If

        Dim img As New Bitmap(rect.Width, rect.Height)
        Using g As Graphics = Graphics.FromImage(img)
            g.CopyFromScreen(rect.Location, Point.Empty, img.Size)
        End Using
        Return img
    End Function
End Module
