﻿Public Class frmCameraAdmin

    Dim monitorChanges As Boolean = False
    Dim currentCameraType As Camera.OCXType = Camera.OCXType.HYPlayer

    Sub LoadAndSelect()
        listCameras.Items.Clear()
        If CurrentAppConfig.Cameras.Count > 0 Then
            For Each camera In CurrentAppConfig.Cameras
                listCameras.Items.Add(camera.Name)
            Next
            listCameras.SelectedIndex = 0
        End If
    End Sub
    Sub LoadSelectedCamera() Handles listCameras.SelectedIndexChanged
        btnSave.Visible = False
        monitorChanges = False

        If CurrentAppConfig.Cameras.Count = 0 Or listCameras.SelectedIndex = -1 Then
            txtName.Text = ""
            txtIP.Text = ""
            txtPort.Text = ""
            txtUser.Text = ""
            txtPassword.Text = ""
            currentCameraType = Camera.OCXType.AxWEBLib
            ShowCurrentCameraType()
            btnDelete.Visible = False
            monitorChanges = True
            Return
        End If

        Dim currentCamera = CurrentAppConfig.Cameras.Item(listCameras.SelectedIndex)
        txtName.Text = currentCamera.Name
        txtIP.Text = currentCamera.IP
        txtPort.Text = currentCamera.Port
        txtUser.Text = currentCamera.User
        txtPassword.Text = currentCamera.Password
        currentCameraType = currentCamera.OCX
        ShowCurrentCameraType()
        panelEditCamera.Visible = True
        btnDelete.Visible = True
        monitorChanges = True
    End Sub
    Sub CurrentCameraWasEdited() Handles txtName.TextChanged, txtIP.TextChanged, txtPort.TextChanged, txtUser.TextChanged, txtPassword.TextChanged
        If Not monitorChanges Then Return

        Dim btnSaveEnabled As Boolean = True

        If String.IsNullOrWhiteSpace(txtName.Text) Then
            btnSaveEnabled = False
        End If
        If String.IsNullOrWhiteSpace(txtIP.Text) Then
            btnSaveEnabled = False
        End If
        If String.IsNullOrWhiteSpace(txtPort.Text) Then
            btnSaveEnabled = False
        End If
        If String.IsNullOrWhiteSpace(txtUser.Text) Then
            btnSaveEnabled = False
        End If
        If String.IsNullOrWhiteSpace(txtPassword.Text) Then
            btnSaveEnabled = False
        End If

        btnSave.Enabled = btnSaveEnabled
        btnSave.Visible = True
    End Sub
    Private Sub ShowCurrentCameraType()
        If currentCameraType = Camera.OCXType.HYPlayer Then
            txtCameraType.Text = "HYPlayer"
        ElseIf currentCameraType = Camera.OCXType.AxWEBLib Then
            txtCameraType.Text = "AxWEBLib"
        End If
    End Sub
    ' ----------------------------

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmAdmin_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        LoadAndSelect()
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        listCameras.SelectedIndex = -1
        panelEditCamera.Visible = True
        monitorChanges = True
        txtName.Focus()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Delete this camera?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Delete Camera") = MsgBoxResult.Yes Then
            DeleteCameraByIndex(listCameras.SelectedIndex)
            listCameras.SelectedIndex = -1
            LoadAndSelect()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim camera As New Camera
        With camera
            .Name = txtName.Text.Trim
            .IP = txtIP.Text.Trim
            .Port = txtPort.Text.Trim
            .User = txtUser.Text.Trim
            .Password = txtPassword.Text.Trim
            .OCX = currentCameraType
        End With
        UpsertCameraByIndex(listCameras.SelectedIndex, camera)
        LoadAndSelect()
    End Sub

    Private Sub btnNextCameraType_Click(sender As Object, e As EventArgs) Handles btnNextCameraType.Click, txtCameraType.Click
        If currentCameraType = Camera.OCXType.HYPlayer Then
            currentCameraType = Camera.OCXType.AxWEBLib
        ElseIf currentCameraType = Camera.OCXType.AxWEBLib Then
            currentCameraType = Camera.OCXType.HYPlayer
        End If
        ShowCurrentCameraType()
        CurrentCameraWasEdited()
    End Sub
End Class
