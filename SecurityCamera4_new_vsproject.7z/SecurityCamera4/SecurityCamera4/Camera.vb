﻿Imports System.Xml.Serialization

<Serializable()>
Public Class Camera

    Public Name As String
    Public IP As String
    Public Port As String
    Public User As String
    Public Password As String
    Public OCX As OCXType

    ' Empty constructor required for serialization.
    Public Sub New()
    End Sub
    Public Sub New(Name As String, IP As String, Port As String, User As String, Password As String, OCX As OCXType)
        Me.Name = Name
        Me.IP = IP
        Me.Port = Port
        Me.User = User
        Me.Password = Password
        Me.OCX = OCX
    End Sub

    Public Enum OCXType
        AxWEBLib
        HYPlayer
    End Enum

End Class
