﻿Public Class frmStart

    Public Property ForceShow As Boolean = False

    Sub LoadAndSelectFirstCamera()
        listCameras.Items.Clear()
        If CurrentAppConfig.Cameras.Count > 0 Then
            For Each camera In CurrentAppConfig.Cameras
                listCameras.Items.Add(camera.Name)
            Next
            listCameras.SelectedIndex = 0
            btnPrimaryAction.Text = "Open"
        Else
            btnPrimaryAction.Text = "Add"
        End If
    End Sub

    Private Sub btnPrimaryAction_Click(sender As Object, e As EventArgs) Handles btnPrimaryAction.Click
        If (listCameras.SelectedIndex = -1) Then
            frmCameraAdmin.ShowDialog()
            LoadAndSelectFirstCamera()
        Else
            OpenCamera(listCameras.SelectedIndex)
        End If
    End Sub

    Private Sub frmStart_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If (CurrentAppConfig.Cameras.Count = 0) Then
            frmCameraAdmin.ShowDialog()
        End If
        LoadAndSelectFirstCamera()
    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        frmCameraAdmin.ShowDialog()
        LoadAndSelectFirstCamera()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnConfig_Click(sender As Object, e As EventArgs) Handles btnConfig.Click
        frmConfig.ShowDialog()
    End Sub

    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles Me.Load
        If (CurrentAppConfig.OpenCameras.Count > 0 And ForceShow = False) Then
            Me.Close()
        End If
    End Sub

    Private Sub btnPhotos_Click(sender As Object, e As EventArgs) Handles btnPhotos.Click
        Using frm As New frmCameraRecords
            Dim cam As New Camera
            cam.Name = listCameras.SelectedItem
            frm.Camera = cam
            frm.ShowDialog()
        End Using
    End Sub
End Class