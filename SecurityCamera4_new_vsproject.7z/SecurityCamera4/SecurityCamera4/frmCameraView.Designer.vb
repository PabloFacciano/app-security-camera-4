﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCameraView
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.FormMenu = New System.Windows.Forms.MenuStrip()
        Me.CameraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenAnotherCameraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RatioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ratio169 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ratio1610 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ratio32 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ratio43 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ratio11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FullToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShortcutsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VisibleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TakePhotoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartStopRecordingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartStopAudioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseCameraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MovementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PhotosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelCenter = New System.Windows.Forms.Panel()
        Me.HoverBar = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.HoverBarButtonsContainer = New System.Windows.Forms.TableLayoutPanel()
        Me.btnVideo = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnAudio = New System.Windows.Forms.Button()
        Me.btnPhoto = New System.Windows.Forms.Button()
        Me.HoverBarMover = New System.Windows.Forms.Panel()
        Me.PanelEnd = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnGoTop = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MovementVelocity = New System.Windows.Forms.TrackBar()
        Me.LabelVelocity = New System.Windows.Forms.Label()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RecordingPanel = New System.Windows.Forms.Panel()
        Me.TRecordingCheck = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundRecording = New System.ComponentModel.BackgroundWorker()
        Me.LoadingPanel = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PanelContent = New System.Windows.Forms.Panel()
        Me.FormMenu.SuspendLayout()
        Me.PanelCenter.SuspendLayout()
        Me.HoverBar.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.HoverBarButtonsContainer.SuspendLayout()
        Me.PanelEnd.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.MovementVelocity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RecordingPanel.SuspendLayout()
        Me.LoadingPanel.SuspendLayout()
        Me.PanelContent.SuspendLayout()
        Me.SuspendLayout()
        '
        'FormMenu
        '
        Me.FormMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CameraToolStripMenuItem, Me.ShortcutsToolStripMenuItem1, Me.PanelsToolStripMenuItem1})
        Me.FormMenu.Location = New System.Drawing.Point(0, 0)
        Me.FormMenu.Name = "FormMenu"
        Me.FormMenu.Size = New System.Drawing.Size(784, 24)
        Me.FormMenu.TabIndex = 2
        Me.FormMenu.Text = "MenuStrip1"
        Me.FormMenu.Visible = False
        '
        'CameraToolStripMenuItem
        '
        Me.CameraToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenAnotherCameraToolStripMenuItem, Me.FullScreenToolStripMenuItem, Me.RatioToolStripMenuItem})
        Me.CameraToolStripMenuItem.Name = "CameraToolStripMenuItem"
        Me.CameraToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.CameraToolStripMenuItem.Text = "&Camera"
        '
        'OpenAnotherCameraToolStripMenuItem
        '
        Me.OpenAnotherCameraToolStripMenuItem.Name = "OpenAnotherCameraToolStripMenuItem"
        Me.OpenAnotherCameraToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.OpenAnotherCameraToolStripMenuItem.Text = "&Open another camera"
        '
        'FullScreenToolStripMenuItem
        '
        Me.FullScreenToolStripMenuItem.CheckOnClick = True
        Me.FullScreenToolStripMenuItem.Name = "FullScreenToolStripMenuItem"
        Me.FullScreenToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.FullScreenToolStripMenuItem.Text = "&FullScreen"
        '
        'RatioToolStripMenuItem
        '
        Me.RatioToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ratio169, Me.ratio1610, Me.ratio32, Me.ratio43, Me.ratio11, Me.ToolStripMenuItem1, Me.FullToolStripMenuItem})
        Me.RatioToolStripMenuItem.Name = "RatioToolStripMenuItem"
        Me.RatioToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.RatioToolStripMenuItem.Text = "&Image Ratio"
        '
        'ratio169
        '
        Me.ratio169.Name = "ratio169"
        Me.ratio169.Size = New System.Drawing.Size(149, 22)
        Me.ratio169.Text = "16:9"
        '
        'ratio1610
        '
        Me.ratio1610.Name = "ratio1610"
        Me.ratio1610.Size = New System.Drawing.Size(149, 22)
        Me.ratio1610.Text = "16:10"
        '
        'ratio32
        '
        Me.ratio32.Name = "ratio32"
        Me.ratio32.Size = New System.Drawing.Size(149, 22)
        Me.ratio32.Text = "3:2"
        '
        'ratio43
        '
        Me.ratio43.Name = "ratio43"
        Me.ratio43.Size = New System.Drawing.Size(149, 22)
        Me.ratio43.Text = "4:3"
        '
        'ratio11
        '
        Me.ratio11.Name = "ratio11"
        Me.ratio11.Size = New System.Drawing.Size(149, 22)
        Me.ratio11.Text = "1:1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(146, 6)
        '
        'FullToolStripMenuItem
        '
        Me.FullToolStripMenuItem.Name = "FullToolStripMenuItem"
        Me.FullToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.FullToolStripMenuItem.Text = "Current Width"
        '
        'ShortcutsToolStripMenuItem1
        '
        Me.ShortcutsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisibleToolStripMenuItem, Me.EditToolStripMenuItem})
        Me.ShortcutsToolStripMenuItem1.Name = "ShortcutsToolStripMenuItem1"
        Me.ShortcutsToolStripMenuItem1.Size = New System.Drawing.Size(69, 20)
        Me.ShortcutsToolStripMenuItem1.Text = "&Shortcuts"
        '
        'VisibleToolStripMenuItem
        '
        Me.VisibleToolStripMenuItem.Checked = True
        Me.VisibleToolStripMenuItem.CheckOnClick = True
        Me.VisibleToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.VisibleToolStripMenuItem.Name = "VisibleToolStripMenuItem"
        Me.VisibleToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.VisibleToolStripMenuItem.Text = "&Visible"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TakePhotoToolStripMenuItem, Me.StartStopRecordingToolStripMenuItem, Me.StartStopAudioToolStripMenuItem, Me.CloseCameraToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.EditToolStripMenuItem.Text = "&Edit"
        '
        'TakePhotoToolStripMenuItem
        '
        Me.TakePhotoToolStripMenuItem.Checked = True
        Me.TakePhotoToolStripMenuItem.CheckOnClick = True
        Me.TakePhotoToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TakePhotoToolStripMenuItem.Name = "TakePhotoToolStripMenuItem"
        Me.TakePhotoToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.TakePhotoToolStripMenuItem.Text = "Take &Photo"
        '
        'StartStopRecordingToolStripMenuItem
        '
        Me.StartStopRecordingToolStripMenuItem.Checked = True
        Me.StartStopRecordingToolStripMenuItem.CheckOnClick = True
        Me.StartStopRecordingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StartStopRecordingToolStripMenuItem.Name = "StartStopRecordingToolStripMenuItem"
        Me.StartStopRecordingToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.StartStopRecordingToolStripMenuItem.Text = "Start/Stop &Recording"
        '
        'StartStopAudioToolStripMenuItem
        '
        Me.StartStopAudioToolStripMenuItem.CheckOnClick = True
        Me.StartStopAudioToolStripMenuItem.Name = "StartStopAudioToolStripMenuItem"
        Me.StartStopAudioToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.StartStopAudioToolStripMenuItem.Text = "Start/Stop &Audio"
        '
        'CloseCameraToolStripMenuItem
        '
        Me.CloseCameraToolStripMenuItem.Checked = True
        Me.CloseCameraToolStripMenuItem.CheckOnClick = True
        Me.CloseCameraToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CloseCameraToolStripMenuItem.Name = "CloseCameraToolStripMenuItem"
        Me.CloseCameraToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.CloseCameraToolStripMenuItem.Text = "&Close Camera"
        '
        'PanelsToolStripMenuItem1
        '
        Me.PanelsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MovementToolStripMenuItem, Me.PhotosToolStripMenuItem})
        Me.PanelsToolStripMenuItem1.Name = "PanelsToolStripMenuItem1"
        Me.PanelsToolStripMenuItem1.Size = New System.Drawing.Size(63, 20)
        Me.PanelsToolStripMenuItem1.Text = "&Window"
        '
        'MovementToolStripMenuItem
        '
        Me.MovementToolStripMenuItem.Checked = True
        Me.MovementToolStripMenuItem.CheckOnClick = True
        Me.MovementToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.MovementToolStripMenuItem.Name = "MovementToolStripMenuItem"
        Me.MovementToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.MovementToolStripMenuItem.Text = "&Movement"
        Me.MovementToolStripMenuItem.Visible = False
        '
        'PhotosToolStripMenuItem
        '
        Me.PhotosToolStripMenuItem.CheckOnClick = True
        Me.PhotosToolStripMenuItem.Name = "PhotosToolStripMenuItem"
        Me.PhotosToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PhotosToolStripMenuItem.Text = "&Photos"
        '
        'PanelCenter
        '
        Me.PanelCenter.BackColor = System.Drawing.Color.Black
        Me.PanelCenter.Controls.Add(Me.HoverBar)
        Me.PanelCenter.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelCenter.Location = New System.Drawing.Point(0, 0)
        Me.PanelCenter.Name = "PanelCenter"
        Me.PanelCenter.Size = New System.Drawing.Size(577, 537)
        Me.PanelCenter.TabIndex = 5
        '
        'HoverBar
        '
        Me.HoverBar.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.HoverBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.HoverBar.Controls.Add(Me.Panel2)
        Me.HoverBar.Location = New System.Drawing.Point(168, 473)
        Me.HoverBar.Name = "HoverBar"
        Me.HoverBar.Padding = New System.Windows.Forms.Padding(1)
        Me.HoverBar.Size = New System.Drawing.Size(240, 35)
        Me.HoverBar.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel2.Controls.Add(Me.HoverBarButtonsContainer)
        Me.Panel2.Controls.Add(Me.HoverBarMover)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(1, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(238, 33)
        Me.Panel2.TabIndex = 0
        '
        'HoverBarButtonsContainer
        '
        Me.HoverBarButtonsContainer.ColumnCount = 4
        Me.HoverBarButtonsContainer.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.HoverBarButtonsContainer.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.HoverBarButtonsContainer.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.HoverBarButtonsContainer.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.HoverBarButtonsContainer.Controls.Add(Me.btnVideo, 0, 0)
        Me.HoverBarButtonsContainer.Controls.Add(Me.btnClose, 2, 0)
        Me.HoverBarButtonsContainer.Controls.Add(Me.btnAudio, 1, 0)
        Me.HoverBarButtonsContainer.Controls.Add(Me.btnPhoto, 0, 0)
        Me.HoverBarButtonsContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HoverBarButtonsContainer.Location = New System.Drawing.Point(14, 0)
        Me.HoverBarButtonsContainer.Name = "HoverBarButtonsContainer"
        Me.HoverBarButtonsContainer.RowCount = 1
        Me.HoverBarButtonsContainer.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.HoverBarButtonsContainer.Size = New System.Drawing.Size(224, 33)
        Me.HoverBarButtonsContainer.TabIndex = 19
        '
        'btnVideo
        '
        Me.btnVideo.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnVideo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnVideo.FlatAppearance.BorderSize = 0
        Me.btnVideo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVideo.Location = New System.Drawing.Point(56, 0)
        Me.btnVideo.Margin = New System.Windows.Forms.Padding(0)
        Me.btnVideo.Name = "btnVideo"
        Me.btnVideo.Size = New System.Drawing.Size(56, 33)
        Me.btnVideo.TabIndex = 21
        Me.btnVideo.Text = "Video"
        Me.btnVideo.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnClose.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Location = New System.Drawing.Point(168, 0)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(0)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(56, 33)
        Me.btnClose.TabIndex = 20
        Me.btnClose.Text = "Hide"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnAudio
        '
        Me.btnAudio.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnAudio.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnAudio.FlatAppearance.BorderSize = 0
        Me.btnAudio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAudio.Location = New System.Drawing.Point(112, 0)
        Me.btnAudio.Margin = New System.Windows.Forms.Padding(0)
        Me.btnAudio.Name = "btnAudio"
        Me.btnAudio.Size = New System.Drawing.Size(56, 33)
        Me.btnAudio.TabIndex = 19
        Me.btnAudio.Text = "Audio"
        Me.btnAudio.UseVisualStyleBackColor = False
        Me.btnAudio.Visible = False
        '
        'btnPhoto
        '
        Me.btnPhoto.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnPhoto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnPhoto.FlatAppearance.BorderSize = 0
        Me.btnPhoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPhoto.Location = New System.Drawing.Point(0, 0)
        Me.btnPhoto.Margin = New System.Windows.Forms.Padding(0)
        Me.btnPhoto.Name = "btnPhoto"
        Me.btnPhoto.Size = New System.Drawing.Size(56, 33)
        Me.btnPhoto.TabIndex = 18
        Me.btnPhoto.Text = "Photo"
        Me.btnPhoto.UseVisualStyleBackColor = False
        '
        'HoverBarMover
        '
        Me.HoverBarMover.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.HoverBarMover.Cursor = System.Windows.Forms.Cursors.SizeAll
        Me.HoverBarMover.Dock = System.Windows.Forms.DockStyle.Left
        Me.HoverBarMover.Location = New System.Drawing.Point(0, 0)
        Me.HoverBarMover.Name = "HoverBarMover"
        Me.HoverBarMover.Size = New System.Drawing.Size(14, 33)
        Me.HoverBarMover.TabIndex = 0
        '
        'PanelEnd
        '
        Me.PanelEnd.AutoScroll = True
        Me.PanelEnd.AutoScrollMargin = New System.Drawing.Size(0, 30)
        Me.PanelEnd.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.PanelEnd.Controls.Add(Me.Panel1)
        Me.PanelEnd.Controls.Add(Me.TableLayoutPanel1)
        Me.PanelEnd.Controls.Add(Me.Label3)
        Me.PanelEnd.Controls.Add(Me.MovementVelocity)
        Me.PanelEnd.Controls.Add(Me.LabelVelocity)
        Me.PanelEnd.Controls.Add(Me.RadioButton2)
        Me.PanelEnd.Controls.Add(Me.RadioButton1)
        Me.PanelEnd.Controls.Add(Me.Label1)
        Me.PanelEnd.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelEnd.ForeColor = System.Drawing.Color.White
        Me.PanelEnd.Location = New System.Drawing.Point(577, 0)
        Me.PanelEnd.Name = "PanelEnd"
        Me.PanelEnd.Size = New System.Drawing.Size(207, 537)
        Me.PanelEnd.TabIndex = 6
        Me.PanelEnd.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1, 537)
        Me.Panel1.TabIndex = 7
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button1, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.btnGoTop, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button4, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Button2, 0, 1)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(15, 223)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(180, 180)
        Me.TableLayoutPanel1.TabIndex = 6
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(59, 120)
        Me.Button1.Margin = New System.Windows.Forms.Padding(0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 60)
        Me.Button1.TabIndex = 21
        Me.Button1.Text = "🔻"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnGoTop
        '
        Me.btnGoTop.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnGoTop.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnGoTop.FlatAppearance.BorderSize = 0
        Me.btnGoTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGoTop.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGoTop.Location = New System.Drawing.Point(59, 0)
        Me.btnGoTop.Margin = New System.Windows.Forms.Padding(0)
        Me.btnGoTop.Name = "btnGoTop"
        Me.btnGoTop.Size = New System.Drawing.Size(60, 60)
        Me.btnGoTop.TabIndex = 22
        Me.btnGoTop.Text = "🔺"
        Me.btnGoTop.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(119, 60)
        Me.Button4.Margin = New System.Windows.Forms.Padding(0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(61, 60)
        Me.Button4.TabIndex = 23
        Me.Button4.Text = ">"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(0, 60)
        Me.Button2.Margin = New System.Windows.Forms.Padding(0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(59, 60)
        Me.Button2.TabIndex = 22
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 192)
        Me.Label3.Margin = New System.Windows.Forms.Padding(3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Controls:"
        '
        'MovementVelocity
        '
        Me.MovementVelocity.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MovementVelocity.Location = New System.Drawing.Point(15, 141)
        Me.MovementVelocity.Minimum = 1
        Me.MovementVelocity.Name = "MovementVelocity"
        Me.MovementVelocity.Size = New System.Drawing.Size(180, 45)
        Me.MovementVelocity.TabIndex = 4
        Me.MovementVelocity.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.MovementVelocity.Value = 1
        '
        'LabelVelocity
        '
        Me.LabelVelocity.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.LabelVelocity.AutoSize = True
        Me.LabelVelocity.Location = New System.Drawing.Point(12, 112)
        Me.LabelVelocity.Margin = New System.Windows.Forms.Padding(3)
        Me.LabelVelocity.Name = "LabelVelocity"
        Me.LabelVelocity.Size = New System.Drawing.Size(47, 13)
        Me.LabelVelocity.TabIndex = 3
        Me.LabelVelocity.Text = "Velocity:"
        '
        'RadioButton2
        '
        Me.RadioButton2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(15, 70)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton2.TabIndex = 2
        Me.RadioButton2.Text = "Click to move"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(15, 47)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(88, 17)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Hold to move"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 16)
        Me.Label1.Margin = New System.Windows.Forms.Padding(3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Movement Type:"
        '
        'RecordingPanel
        '
        Me.RecordingPanel.BackColor = System.Drawing.Color.Black
        Me.RecordingPanel.Controls.Add(Me.PanelCenter)
        Me.RecordingPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RecordingPanel.ForeColor = System.Drawing.Color.White
        Me.RecordingPanel.Location = New System.Drawing.Point(0, 0)
        Me.RecordingPanel.Name = "RecordingPanel"
        Me.RecordingPanel.Size = New System.Drawing.Size(577, 537)
        Me.RecordingPanel.TabIndex = 7
        '
        'TRecordingCheck
        '
        Me.TRecordingCheck.Interval = 1000
        '
        'BackgroundRecording
        '
        Me.BackgroundRecording.WorkerReportsProgress = True
        Me.BackgroundRecording.WorkerSupportsCancellation = True
        '
        'LoadingPanel
        '
        Me.LoadingPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.LoadingPanel.Controls.Add(Me.Label4)
        Me.LoadingPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LoadingPanel.ForeColor = System.Drawing.Color.White
        Me.LoadingPanel.Location = New System.Drawing.Point(0, 0)
        Me.LoadingPanel.Name = "LoadingPanel"
        Me.LoadingPanel.Size = New System.Drawing.Size(784, 561)
        Me.LoadingPanel.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(278, 268)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(229, 25)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Loading... Please wait."
        '
        'PanelContent
        '
        Me.PanelContent.Controls.Add(Me.RecordingPanel)
        Me.PanelContent.Controls.Add(Me.PanelEnd)
        Me.PanelContent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelContent.Location = New System.Drawing.Point(0, 24)
        Me.PanelContent.Name = "PanelContent"
        Me.PanelContent.Size = New System.Drawing.Size(784, 537)
        Me.PanelContent.TabIndex = 9
        '
        'frmCameraView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(784, 561)
        Me.Controls.Add(Me.PanelContent)
        Me.Controls.Add(Me.FormMenu)
        Me.Controls.Add(Me.LoadingPanel)
        Me.MainMenuStrip = Me.FormMenu
        Me.MinimumSize = New System.Drawing.Size(100, 100)
        Me.Name = "frmCameraView"
        Me.Text = "Camera"
        Me.FormMenu.ResumeLayout(False)
        Me.FormMenu.PerformLayout()
        Me.PanelCenter.ResumeLayout(False)
        Me.HoverBar.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.HoverBarButtonsContainer.ResumeLayout(False)
        Me.PanelEnd.ResumeLayout(False)
        Me.PanelEnd.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.MovementVelocity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RecordingPanel.ResumeLayout(False)
        Me.LoadingPanel.ResumeLayout(False)
        Me.LoadingPanel.PerformLayout()
        Me.PanelContent.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FormMenu As MenuStrip
    Friend WithEvents CameraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PanelCenter As Panel
    Friend WithEvents PanelEnd As Panel
    Friend WithEvents OpenAnotherCameraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FullScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HoverBar As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents RatioToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ratio169 As ToolStripMenuItem
    Friend WithEvents ratio43 As ToolStripMenuItem
    Friend WithEvents ratio1610 As ToolStripMenuItem
    Friend WithEvents ratio32 As ToolStripMenuItem
    Friend WithEvents HoverBarMover As Panel
    Friend WithEvents ShortcutsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents VisibleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PanelsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents MovementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PhotosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TakePhotoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StartStopRecordingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StartStopAudioToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HoverBarButtonsContainer As TableLayoutPanel
    Friend WithEvents btnVideo As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnAudio As Button
    Friend WithEvents btnPhoto As Button
    Friend WithEvents CloseCameraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button1 As Button
    Friend WithEvents btnGoTop As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents MovementVelocity As TrackBar
    Friend WithEvents LabelVelocity As Label
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents RecordingPanel As Panel
    Friend WithEvents TRecordingCheck As Timer
    Friend WithEvents BackgroundRecording As System.ComponentModel.BackgroundWorker
    Friend WithEvents LoadingPanel As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents PanelContent As Panel
    Friend WithEvents ratio11 As ToolStripMenuItem
    Friend WithEvents FullToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
End Class
