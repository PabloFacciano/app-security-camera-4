﻿Public Class frmCameraRecords

    Private Class PhotoFile

        Public Property FileName As String
        Public Property Type As PhotoType
        Public Property Image As Image

        Public Enum PhotoType
            Any
            Photo
            Video
            Timelapse
        End Enum

    End Class

    Public Property Camera As Camera

    Private Filenames As List(Of String)
    Private Images As List(Of Bitmap)


    Private Sub LoadFilesInFolder()
        Dim currentCameraDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop & "\SecurityCamera4\" & Camera.Name
        Filenames = My.Computer.FileSystem.GetFiles(currentCameraDirectory, FileIO.SearchOption.SearchAllSubDirectories).ToList
        Filenames.Sort()
        If Images IsNot Nothing Then
            For Each img As Bitmap In Images
                If img IsNot Nothing Then
                    img.Dispose()
                End If
            Next
        End If
        Images = New List(Of Bitmap)
        For Each file In Filenames
            Images.Add(Nothing)
        Next
    End Sub
    Private Sub LoadFileNamesInBox()
        listFiles.Items.Clear()
        For Each record In Filenames
            listFiles.Items.Add(IO.Path.GetFileName(record))
        Next
    End Sub

    Private Sub LoadCurrentAndNextNImages() Handles listFiles.SelectedIndexChanged

        If listFiles.SelectedIndex = -1 Then
            Viewer.Image = Nothing
            Return
        End If

        Dim minImagesBefore As Integer = 0
        Dim maxImagesAfter As Integer = 10


        Dim currentFileIndex As Integer = listFiles.SelectedIndex
        Dim currentImage As Bitmap
        Dim currentFileNamme As String


        For x As Integer = 0 To Filenames.Count - 1
            currentFileNamme = Filenames(x)
            currentImage = Images(x)

            If (x >= (currentFileIndex - minImagesBefore) And x < (currentFileIndex + maxImagesAfter)) Then
                ' load temp image

                If currentImage Is Nothing Then
                    If IO.File.Exists(currentFileNamme) Then
                        Using img1 As New Bitmap(currentFileNamme)
                            Images.Item(x) = New Bitmap(img1)
                        End Using
                    End If
                End If

            Else
                ' remove temp image
                If currentImage IsNot Nothing Then
                    Images(x).Dispose()
                    Images(x) = Nothing
                End If
            End If
        Next

        Viewer.Image = Images(currentFileIndex)


    End Sub


    Private Sub frmCameraRecords_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Camera Is Nothing Then Me.Close()
    End Sub
    Private Sub frmCameraRecords_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Application.DoEvents()
        LoadFilesInFolder()
        LoadFileNamesInBox()
        LoadingPanel.Visible = False
    End Sub

    ' Menu
    Private Sub ShowVideoControlsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowVideoControlsToolStripMenuItem.Click
        ToolStrip1.Visible = ShowVideoControlsToolStripMenuItem.Checked
    End Sub
    Private Sub ShowFilesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowFilesToolStripMenuItem.Click
        PanelFiles.Visible = ShowFilesToolStripMenuItem.Checked
    End Sub

    Private Sub TFrames_Tick(sender As Object, e As EventArgs) Handles TFrames.Tick
        If listFiles.SelectedIndex >= listFiles.Items.Count - 1 Then
            listFiles.SelectedIndex = -1
            TFrames.Stop()
            Return
        End If
        listFiles.SelectedIndex += 1
    End Sub

    Private Sub StopVideo_Click(sender As Object, e As EventArgs) Handles StopVideo.Click
        TFrames.Stop()
    End Sub

    Private Sub LastFrame_Click(sender As Object, e As EventArgs)
        If listFiles.SelectedIndex > 0 Then
            listFiles.SelectedIndex -= 1
        End If
    End Sub

    Private Sub NextFrame_Click(sender As Object, e As EventArgs)
        If listFiles.SelectedIndex < listFiles.Items.Count - 1 Then
            listFiles.SelectedIndex += 1
        End If
    End Sub

    Private Sub PlayAt60_Click(sender As Object, e As EventArgs) Handles PlayAt60.Click
        TFrames.Interval = 1000 / 60
        TFrames.Start()
    End Sub

    Private Sub PlayAt30_Click(sender As Object, e As EventArgs) Handles PlayAt30.Click
        TFrames.Interval = 1000 / 30
        TFrames.Start()
    End Sub

    Private Sub PlayAt10_Click(sender As Object, e As EventArgs) Handles PlayAt10.Click
        TFrames.Interval = 1000 / 10
        TFrames.Start()
    End Sub

    Private Sub PlayAt5_Click(sender As Object, e As EventArgs) Handles PlayAt5.Click
        TFrames.Interval = 1000 / 5
        TFrames.Start()
    End Sub

    Private Sub PlayAt1_Click(sender As Object, e As EventArgs) Handles PlayAt1.Click
        TFrames.Interval = 1000
        TFrames.Start()
    End Sub


    Private Sub CustomToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomToolStripMenuItem.Click
        Dim n As String = InputBox("Insert FPS:", "Play", 10)
        If IsNumeric(n) Then
            TFrames.Interval = 1000 / CInt(n)
            TFrames.Start()
        End If
    End Sub

    Private Sub frmCameraRecords_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        For Each f As Image In Images
            If f IsNot Nothing Then
                f.Dispose()
            End If
        Next
        Images.Clear()
    End Sub

End Class