﻿Imports System.Xml.Serialization

<Serializable()>
Public Class AppConfig

    Public Cameras As List(Of Camera)
    Public OpenCameras As List(Of Integer)
    Public VideoFPS As Integer
    Public AutoStartRecording As Boolean
    Public Timelapse As Boolean
    Public TimeLapseFPS As Integer

    ' Empty constructor required for serialization.
    Public Sub New()
    End Sub

    Public Shared Function DefaultAppConfig() As AppConfig
        Dim config As New AppConfig

        config.Cameras = New List(Of Camera)
        config.OpenCameras = New List(Of Integer)
        config.AutoStartRecording = True
        config.VideoFPS = 10
        config.Timelapse = True
        config.TimeLapseFPS = 48

        Return config
    End Function

End Class
