﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCameraRecords
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCameraRecords))
        Me.listFiles = New System.Windows.Forms.ListBox()
        Me.PanelFiles = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ConfigToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowVideoControlsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.PlayVideo = New System.Windows.Forms.ToolStripDropDownButton()
        Me.FramesPerSecondToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayAt60 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayAt30 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayAt10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayAt5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayAt1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopVideo = New System.Windows.Forms.ToolStripButton()
        Me.Viewer = New System.Windows.Forms.PictureBox()
        Me.LoadingPanel = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TFrames = New System.Windows.Forms.Timer(Me.components)
        Me.PanelFiles.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.Viewer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LoadingPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'listFiles
        '
        Me.listFiles.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.listFiles.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.listFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listFiles.ForeColor = System.Drawing.SystemColors.Window
        Me.listFiles.FormattingEnabled = True
        Me.listFiles.IntegralHeight = False
        Me.listFiles.Location = New System.Drawing.Point(0, 0)
        Me.listFiles.Name = "listFiles"
        Me.listFiles.Size = New System.Drawing.Size(249, 476)
        Me.listFiles.TabIndex = 2
        '
        'PanelFiles
        '
        Me.PanelFiles.Controls.Add(Me.listFiles)
        Me.PanelFiles.Controls.Add(Me.Panel2)
        Me.PanelFiles.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelFiles.Location = New System.Drawing.Point(0, 85)
        Me.PanelFiles.Name = "PanelFiles"
        Me.PanelFiles.Size = New System.Drawing.Size(250, 476)
        Me.PanelFiles.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(249, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1, 476)
        Me.Panel2.TabIndex = 3
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConfigToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 36)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ConfigToolStripMenuItem
        '
        Me.ConfigToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowFilesToolStripMenuItem, Me.ShowVideoControlsToolStripMenuItem})
        Me.ConfigToolStripMenuItem.Name = "ConfigToolStripMenuItem"
        Me.ConfigToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.ConfigToolStripMenuItem.Text = "&Config"
        '
        'ShowFilesToolStripMenuItem
        '
        Me.ShowFilesToolStripMenuItem.Checked = True
        Me.ShowFilesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowFilesToolStripMenuItem.Name = "ShowFilesToolStripMenuItem"
        Me.ShowFilesToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.ShowFilesToolStripMenuItem.Text = "Show &Files"
        '
        'ShowVideoControlsToolStripMenuItem
        '
        Me.ShowVideoControlsToolStripMenuItem.Checked = True
        Me.ShowVideoControlsToolStripMenuItem.CheckOnClick = True
        Me.ShowVideoControlsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowVideoControlsToolStripMenuItem.Name = "ShowVideoControlsToolStripMenuItem"
        Me.ShowVideoControlsToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.ShowVideoControlsToolStripMenuItem.Text = "Show &Video Controls"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StopVideo, Me.PlayVideo})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 60)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(784, 25)
        Me.ToolStrip1.TabIndex = 5
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'PlayVideo
        '
        Me.PlayVideo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.PlayVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.PlayVideo.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FramesPerSecondToolStripMenuItem, Me.PlayAt60, Me.PlayAt30, Me.PlayAt10, Me.PlayAt5, Me.PlayAt1, Me.ToolStripMenuItem1, Me.CustomToolStripMenuItem})
        Me.PlayVideo.Image = CType(resources.GetObject("PlayVideo.Image"), System.Drawing.Image)
        Me.PlayVideo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PlayVideo.Name = "PlayVideo"
        Me.PlayVideo.Padding = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.PlayVideo.ShowDropDownArrow = False
        Me.PlayVideo.Size = New System.Drawing.Size(53, 22)
        Me.PlayVideo.Text = "Play"
        '
        'FramesPerSecondToolStripMenuItem
        '
        Me.FramesPerSecondToolStripMenuItem.Enabled = False
        Me.FramesPerSecondToolStripMenuItem.Name = "FramesPerSecondToolStripMenuItem"
        Me.FramesPerSecondToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FramesPerSecondToolStripMenuItem.Text = "Frames per second"
        '
        'PlayAt60
        '
        Me.PlayAt60.Name = "PlayAt60"
        Me.PlayAt60.Size = New System.Drawing.Size(180, 22)
        Me.PlayAt60.Text = "60"
        '
        'PlayAt30
        '
        Me.PlayAt30.Name = "PlayAt30"
        Me.PlayAt30.Size = New System.Drawing.Size(180, 22)
        Me.PlayAt30.Text = "30"
        '
        'PlayAt10
        '
        Me.PlayAt10.Name = "PlayAt10"
        Me.PlayAt10.Size = New System.Drawing.Size(180, 22)
        Me.PlayAt10.Text = "10"
        '
        'PlayAt5
        '
        Me.PlayAt5.Name = "PlayAt5"
        Me.PlayAt5.Size = New System.Drawing.Size(180, 22)
        Me.PlayAt5.Text = "5"
        '
        'PlayAt1
        '
        Me.PlayAt1.Name = "PlayAt1"
        Me.PlayAt1.Size = New System.Drawing.Size(180, 22)
        Me.PlayAt1.Text = "1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(177, 6)
        '
        'CustomToolStripMenuItem
        '
        Me.CustomToolStripMenuItem.Name = "CustomToolStripMenuItem"
        Me.CustomToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CustomToolStripMenuItem.Text = "&Custom"
        '
        'StopVideo
        '
        Me.StopVideo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.StopVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.StopVideo.Image = CType(resources.GetObject("StopVideo.Image"), System.Drawing.Image)
        Me.StopVideo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.StopVideo.Name = "StopVideo"
        Me.StopVideo.Padding = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.StopVideo.Size = New System.Drawing.Size(55, 22)
        Me.StopVideo.Text = "Stop"
        '
        'Viewer
        '
        Me.Viewer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Viewer.Location = New System.Drawing.Point(250, 85)
        Me.Viewer.Name = "Viewer"
        Me.Viewer.Size = New System.Drawing.Size(534, 476)
        Me.Viewer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Viewer.TabIndex = 6
        Me.Viewer.TabStop = False
        '
        'LoadingPanel
        '
        Me.LoadingPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LoadingPanel.Controls.Add(Me.Label1)
        Me.LoadingPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.LoadingPanel.Location = New System.Drawing.Point(0, 0)
        Me.LoadingPanel.Name = "LoadingPanel"
        Me.LoadingPanel.Size = New System.Drawing.Size(784, 36)
        Me.LoadingPanel.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(293, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(198, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Loading files... Please wait."
        '
        'TFrames
        '
        Me.TFrames.Interval = 1000
        '
        'frmCameraRecords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(784, 561)
        Me.Controls.Add(Me.Viewer)
        Me.Controls.Add(Me.PanelFiles)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.LoadingPanel)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmCameraRecords"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Camera"
        Me.PanelFiles.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.Viewer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LoadingPanel.ResumeLayout(False)
        Me.LoadingPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents listFiles As ListBox
    Friend WithEvents PanelFiles As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ConfigToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShowFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents PlayVideo As ToolStripDropDownButton
    Friend WithEvents PlayAt60 As ToolStripMenuItem
    Friend WithEvents PlayAt30 As ToolStripMenuItem
    Friend WithEvents PlayAt10 As ToolStripMenuItem
    Friend WithEvents PlayAt5 As ToolStripMenuItem
    Friend WithEvents PlayAt1 As ToolStripMenuItem
    Friend WithEvents FramesPerSecondToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StopVideo As ToolStripButton
    Friend WithEvents ShowVideoControlsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Viewer As PictureBox
    Friend WithEvents LoadingPanel As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents TFrames As Timer
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
    Friend WithEvents CustomToolStripMenuItem As ToolStripMenuItem
End Class
