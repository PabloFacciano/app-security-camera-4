﻿Imports System.Runtime.InteropServices

Public Class frmCameraView

    ' Ratio
    Public Property CameraRatio As Single
    Private Sub SetImageRatio(w As Single, h As Single)
        CameraRatio = w / h

        ratio1610.Checked = CBool(h = 10)
        ratio169.Checked = CBool(h = 9)
        ratio43.Checked = CBool(h = 3)
        ratio32.Checked = CBool(h = 2)

        UseImageRatio()
    End Sub
    Private Sub UseImageRatio() Handles PanelCenter.Resize

        Dim ctrl As Control = getCurrentCameraControl()
        If ctrl Is Nothing Then
            Return
        End If


        Dim containerRatio = 1.0F * PanelCenter.Width / PanelCenter.Height
        If (containerRatio < CameraRatio) Then
            ctrl.Width = PanelCenter.Width
            ctrl.Height = Int(ctrl.Width / CameraRatio)
            ctrl.Top = (PanelCenter.Height - ctrl.Height) / 2
            ctrl.Left = 0
        Else
            ctrl.Height = PanelCenter.Height
            ctrl.Width = Int(ctrl.Height * CameraRatio)
            ctrl.Top = 0
            ctrl.Left = (PanelCenter.Width - ctrl.Width) / 2
        End If

        FixHoverBarLocation(HoverBar, Nothing)

    End Sub
    Private Sub ratio1610_Click(sender As Object, e As EventArgs) Handles ratio1610.Click
        SetImageRatio(16, 10)
    End Sub
    Private Sub ratio169_Click(sender As Object, e As EventArgs) Handles ratio169.Click
        SetImageRatio(16, 9)
    End Sub
    Private Sub ratio43_Click(sender As Object, e As EventArgs) Handles ratio43.Click
        SetImageRatio(4, 3)
    End Sub
    Private Sub ratio32_Click(sender As Object, e As EventArgs) Handles ratio32.Click
        SetImageRatio(3, 2)
    End Sub
    Private Sub ratio11_Click(sender As Object, e As EventArgs) Handles ratio11.Click
        SetImageRatio(1, 1)
    End Sub
    Private Sub FullToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FullToolStripMenuItem.Click
        SetImageRatio(PanelCenter.Width, PanelCenter.Height)
    End Sub

    Private Sub OpenAnotherCameraToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenAnotherCameraToolStripMenuItem.Click
        If FullScreenToolStripMenuItem.Checked Then
            FullScreenToolStripMenuItem.Checked = False
        End If
        frmStart.ForceShow = True
        frmStart.Show()
        frmStart.BringToFront()
    End Sub

    ' Start/Stop
    Public Property Camera As Camera
    Private WithEvents ocx As AxWEBLib.AxWeb
    Private WithEvents browser As WebBrowser
    Private Const ERROR_AT_LOGIN = -11700
    Private Function getCurrentCameraControl() As Object
        If ocx IsNot Nothing Then
            Return ocx
        ElseIf browser IsNot Nothing Then
            Return browser
        End If
        Return Nothing
    End Function
    Private Sub Start_AxWEBLib_Camera()
        SetImageRatio(16, 9)

        ocx = New AxWEBLib.AxWeb
        PanelCenter.Controls.Add(ocx)

        Dim loginResult = ocx.Login(Camera.IP, Camera.Port, Camera.User, Camera.Password)
        Console.WriteLine("Login: " & loginResult)

        If (ERROR_AT_LOGIN = loginResult) Then
            MsgBox("Error at login. Closing camera.", MsgBoxStyle.Critical, Me.Text)
            Me.Close()
        End If

        Console.WriteLine("GetDeviceState: " & ocx.GetDeviceState(1, 0))
        Console.WriteLine("GetChannelName: " & ocx.GetChannelName)

        Dim playAllResult = ocx.PlayAll()
        Console.WriteLine("PlayAll: " & playAllResult)

        ' Console.WriteLine("SetSpecialParamEx 10001: " & ocx.SetSpecialParamEx(10001, 0, 0, 0))
        ' Console.WriteLine("SetSpecialParamEx 10003: " & ocx.SetSpecialParamEx(10003, 0, 0, 0))
        Console.WriteLine("SetSpecialParamEx2 5004: " & ocx.SetSpecialParamEx2(5004, 0, 0, 0))
    End Sub
    Private Sub Stop_AxWebLib_Camera()
        ocx.Logout()
    End Sub
    Private Sub Start_HYPlayer_Camera()

        browser = New WebBrowser
        browser.ScrollBarsEnabled = False
        browser.DocumentText = App.HTML_CameraWebPage(Camera.IP, Camera.Port, Camera.User, Camera.Password)
        PanelCenter.Controls.Add(browser)

    End Sub
    Private Sub frmCameraView_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        CheckForIllegalCrossThreadCalls = False
        PanelCenter.BackColor = Color.Black
        LoadingPanel.Dock = DockStyle.Fill
        LoadingPanel.BringToFront()
        Application.DoEvents()

        If Camera.OCX = Camera.OCXType.AxWEBLib Then
            Start_AxWEBLib_Camera()
        ElseIf Camera.OCX = Camera.OCXType.HYPlayer Then
            Start_HYPlayer_Camera()
        End If
        SetImageRatio(16, 9)

        Application.DoEvents()
        LoadingPanel.Visible = False
        FormMenu.Visible = True
    End Sub
    Private Sub frmCameraView_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If Camera.OCX = Camera.OCXType.AxWEBLib Then
            Stop_AxWebLib_Camera()
        End If
    End Sub

    ' Menu: Camera
    Private Sub FullScreenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FullScreenToolStripMenuItem.Click
        If FullScreenToolStripMenuItem.Checked Then
            Me.BringToFront()
            Me.FormBorderStyle = FormBorderStyle.None
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.FormBorderStyle = FormBorderStyle.Sizable
            Me.WindowState = FormWindowState.Normal
        End If
    End Sub
    Private Sub VisibleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VisibleToolStripMenuItem.Click
        HoverBar.Visible = VisibleToolStripMenuItem.Checked

    End Sub

    ' HoverBar Drag&Drop
    Private HoverMargin As Integer = 10
    Private Sub PictureBox1_MouseDown(ByVal sender As Control,
                                    ByVal e As System.Windows.Forms.MouseEventArgs) _
                                    Handles HoverBarMover.MouseDown
        sender.Tag = True
    End Sub
    Private Sub PictureBox1_MouseMove(ByVal sender As Control,
                                      ByVal e As System.Windows.Forms.MouseEventArgs) _
                                      Handles HoverBarMover.MouseMove
        If sender.Tag IsNot Nothing Then
            Dim newX As Integer = HoverBar.Left + e.X - (HoverBarMover.Width / 2)
            Dim newY As Integer = HoverBar.Top + e.Y - (HoverBarMover.Height / 2)
            If newX < HoverMargin Then
                newX = HoverMargin
            ElseIf newX > PanelCenter.Width - HoverMargin - HoverBar.Width Then
                newX = PanelCenter.Width - HoverMargin - HoverBar.Width
            End If
            If newY < HoverMargin Then
                newY = HoverMargin
            ElseIf newY > PanelCenter.Height - HoverMargin - HoverBar.Height Then
                newY = PanelCenter.Height - HoverMargin - HoverBar.Height
            End If
            If newX <> HoverBar.Left Or newY <> HoverBar.Top Then
                HoverBar.Location = New Point(newX, newY)
            End If
        End If
    End Sub
    Private Sub PictureBox1_MouseUp(ByVal sender As Control,
                                    ByVal e As System.Windows.Forms.MouseEventArgs) _
                                    Handles HoverBarMover.MouseUp
        sender.Tag = Nothing
    End Sub
    Private Sub FixHoverBarLocation(sender As Control, e As EventArgs) Handles HoverBarMover.LocationChanged

        If HoverBar.Left < HoverMargin Then
            HoverBar.Left = HoverMargin
        ElseIf HoverBar.Left > PanelCenter.Width - HoverMargin - HoverBar.Width Then
            HoverBar.Left = PanelCenter.Width - HoverMargin - HoverBar.Width
        End If
        If HoverBar.Top < HoverMargin Then
            HoverBar.Top = HoverMargin
        ElseIf HoverBar.Top > PanelCenter.Height - HoverMargin - HoverBar.Height Then
            HoverBar.Top = PanelCenter.Height - HoverMargin - HoverBar.Height
        End If
    End Sub

    ' Menus
    Private Sub TakePhotoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TakePhotoToolStripMenuItem.Click
        btnPhoto.Visible = TakePhotoToolStripMenuItem.Checked
    End Sub
    Private Sub StartStopRecordingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartStopRecordingToolStripMenuItem.Click
        btnVideo.Visible = StartStopRecordingToolStripMenuItem.Checked
    End Sub
    Private Sub StartStopAudioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartStopAudioToolStripMenuItem.Click
        btnAudio.Visible = StartStopAudioToolStripMenuItem.Checked
    End Sub
    Private Sub CloseCameraToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseCameraToolStripMenuItem.Click
        btnClose.Visible = CloseCameraToolStripMenuItem.Checked
    End Sub
    Private Sub MovementToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MovementToolStripMenuItem.Click
        PanelEnd.Visible = MovementToolStripMenuItem.Checked
    End Sub

    ' Photo maker
    Private Sub btnPhoto_Click(sender As Object, e As EventArgs) Handles btnPhoto.Click
        btnPhoto.Enabled = False
        btnPhoto.Text = "Wait"
        RecordingPanel.BackColor = Color.Maroon
        PrepareForPhoto()
        Application.DoEvents()
        Dim photo As String = TakePhoto("Photos")
        RecordingPanel.BackColor = Color.Black
        btnPhoto.Text = "Photo"
        btnPhoto.Enabled = True
        Process.Start(photo) ' Open photo in current windows photo viewer

    End Sub
    Private Sub PrepareForPhoto()
    End Sub
    Private Function TakePhoto(folder As String) As String
        If (Me.WindowState = FormWindowState.Minimized) Then
            Me.WindowState = FormWindowState.Maximized
        End If
        Me.TopMost = True

        Dim directory As String = My.Computer.FileSystem.SpecialDirectories.Desktop & "/SecurityCamera4/" & Camera.Name & "/" & folder & "/"
        IO.Directory.CreateDirectory(directory)

        Dim filename As String = DateTime.Now.ToString("yyyy-MM-dd--HH-mm-ss-fffffff") & ".jpeg"

        Dim folderPlusFilename = directory & filename

        Using bmp As Bitmap = ControlToBitmap(getCurrentCameraControl(), True)
            bmp.Save(folderPlusFilename, System.Drawing.Imaging.ImageFormat.Jpeg)
        End Using

        Me.TopMost = False

        Return folderPlusFilename
    End Function

    ' Video: Massive photo maker
    Private Sub btnVideo_Click(sender As Object, e As EventArgs) Handles btnVideo.Click
        If TRecordingCheck.Enabled Then
            RecordingPanel.Padding = New Padding(0)
            BackgroundRecording.CancelAsync()
            TRecordingCheck.Stop()
        Else
            RecordingPanel.Padding = New Padding(4)
            TRecordingCheck.Start()
            BackgroundRecording.RunWorkerAsync()
        End If
    End Sub
    Private Sub TRecordingCheck_Tick(sender As Object, e As EventArgs) Handles TRecordingCheck.Tick
        If RecordingPanel.BackColor = Color.Maroon Then
            RecordingPanel.BackColor = Color.Black
        Else
            RecordingPanel.BackColor = Color.Maroon
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        VisibleToolStripMenuItem.Checked = False
        HoverBar.Visible = False
    End Sub

    Private Sub BackgroundRecording_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundRecording.DoWork
        Dim fps As Integer = CurrentAppConfig.VideoFPS
        If fps = 0 Then fps = 1
        Do
            Try
                PrepareForPhoto()
                TakePhoto("Video")
            Catch ex As Exception
                Console.WriteLine("Exception: " & ex.Message)
            End Try
            Threading.Thread.Sleep(1000 / fps)
        Loop Until BackgroundRecording.CancellationPending
    End Sub

    Private Sub PhotosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PhotosToolStripMenuItem.Click
        Using frm As New frmCameraRecords
            frm.Camera = Camera
            frm.ShowDialog()
        End Using
    End Sub
End Class