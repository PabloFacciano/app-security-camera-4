﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfig
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.btnAutoStartON = New System.Windows.Forms.RadioButton()
        Me.btnAutoStartOFF = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnFPS1 = New System.Windows.Forms.RadioButton()
        Me.btnFPS10 = New System.Windows.Forms.RadioButton()
        Me.btnFPS30 = New System.Windows.Forms.RadioButton()
        Me.btnFPS60 = New System.Windows.Forms.RadioButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnConfigExport = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnTimelapse1 = New System.Windows.Forms.RadioButton()
        Me.btnTimelapse12 = New System.Windows.Forms.RadioButton()
        Me.btnTimelapse24 = New System.Windows.Forms.RadioButton()
        Me.btnTimelapse48 = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnTimelapseON = New System.Windows.Forms.RadioButton()
        Me.btnTimelapseOFF = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Panel7)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(1, 30)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Padding = New System.Windows.Forms.Padding(3)
        Me.Panel1.Size = New System.Drawing.Size(568, 317)
        Me.Panel1.TabIndex = 24
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.btnAutoStartON)
        Me.Panel7.Controls.Add(Me.btnAutoStartOFF)
        Me.Panel7.Location = New System.Drawing.Point(306, 52)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(120, 30)
        Me.Panel7.TabIndex = 43
        '
        'btnAutoStartON
        '
        Me.btnAutoStartON.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnAutoStartON.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnAutoStartON.Checked = True
        Me.btnAutoStartON.FlatAppearance.BorderSize = 0
        Me.btnAutoStartON.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnAutoStartON.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAutoStartON.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoStartON.Location = New System.Drawing.Point(0, 0)
        Me.btnAutoStartON.Margin = New System.Windows.Forms.Padding(0)
        Me.btnAutoStartON.Name = "btnAutoStartON"
        Me.btnAutoStartON.Size = New System.Drawing.Size(60, 30)
        Me.btnAutoStartON.TabIndex = 35
        Me.btnAutoStartON.TabStop = True
        Me.btnAutoStartON.Text = "ON"
        Me.btnAutoStartON.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnAutoStartON.UseVisualStyleBackColor = False
        '
        'btnAutoStartOFF
        '
        Me.btnAutoStartOFF.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnAutoStartOFF.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnAutoStartOFF.FlatAppearance.BorderSize = 0
        Me.btnAutoStartOFF.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnAutoStartOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAutoStartOFF.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoStartOFF.Location = New System.Drawing.Point(60, 0)
        Me.btnAutoStartOFF.Margin = New System.Windows.Forms.Padding(0)
        Me.btnAutoStartOFF.Name = "btnAutoStartOFF"
        Me.btnAutoStartOFF.Size = New System.Drawing.Size(60, 30)
        Me.btnAutoStartOFF.TabIndex = 34
        Me.btnAutoStartOFF.Text = "OFF"
        Me.btnAutoStartOFF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnAutoStartOFF.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btnFPS1)
        Me.Panel6.Controls.Add(Me.btnFPS10)
        Me.Panel6.Controls.Add(Me.btnFPS30)
        Me.Panel6.Controls.Add(Me.btnFPS60)
        Me.Panel6.Location = New System.Drawing.Point(306, 131)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(240, 30)
        Me.Panel6.TabIndex = 42
        '
        'btnFPS1
        '
        Me.btnFPS1.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnFPS1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnFPS1.FlatAppearance.BorderSize = 0
        Me.btnFPS1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnFPS1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFPS1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFPS1.Location = New System.Drawing.Point(180, 0)
        Me.btnFPS1.Margin = New System.Windows.Forms.Padding(0)
        Me.btnFPS1.Name = "btnFPS1"
        Me.btnFPS1.Size = New System.Drawing.Size(60, 30)
        Me.btnFPS1.TabIndex = 20
        Me.btnFPS1.Tag = "1"
        Me.btnFPS1.Text = "1"
        Me.btnFPS1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnFPS1.UseVisualStyleBackColor = False
        '
        'btnFPS10
        '
        Me.btnFPS10.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnFPS10.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnFPS10.Checked = True
        Me.btnFPS10.FlatAppearance.BorderSize = 0
        Me.btnFPS10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnFPS10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFPS10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFPS10.Location = New System.Drawing.Point(120, 0)
        Me.btnFPS10.Margin = New System.Windows.Forms.Padding(0)
        Me.btnFPS10.Name = "btnFPS10"
        Me.btnFPS10.Size = New System.Drawing.Size(60, 30)
        Me.btnFPS10.TabIndex = 19
        Me.btnFPS10.TabStop = True
        Me.btnFPS10.Tag = "10"
        Me.btnFPS10.Text = "10"
        Me.btnFPS10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnFPS10.UseVisualStyleBackColor = False
        '
        'btnFPS30
        '
        Me.btnFPS30.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnFPS30.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnFPS30.FlatAppearance.BorderSize = 0
        Me.btnFPS30.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnFPS30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFPS30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFPS30.Location = New System.Drawing.Point(60, 0)
        Me.btnFPS30.Margin = New System.Windows.Forms.Padding(0)
        Me.btnFPS30.Name = "btnFPS30"
        Me.btnFPS30.Size = New System.Drawing.Size(60, 30)
        Me.btnFPS30.TabIndex = 18
        Me.btnFPS30.Tag = "30"
        Me.btnFPS30.Text = "30"
        Me.btnFPS30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnFPS30.UseVisualStyleBackColor = False
        '
        'btnFPS60
        '
        Me.btnFPS60.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnFPS60.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnFPS60.FlatAppearance.BorderSize = 0
        Me.btnFPS60.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnFPS60.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFPS60.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFPS60.Location = New System.Drawing.Point(0, 0)
        Me.btnFPS60.Margin = New System.Windows.Forms.Padding(0)
        Me.btnFPS60.Name = "btnFPS60"
        Me.btnFPS60.Size = New System.Drawing.Size(60, 30)
        Me.btnFPS60.TabIndex = 17
        Me.btnFPS60.Tag = "60"
        Me.btnFPS60.Text = "60"
        Me.btnFPS60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnFPS60.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnConfigExport)
        Me.Panel5.Location = New System.Drawing.Point(27, 210)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(240, 29)
        Me.Panel5.TabIndex = 41
        '
        'btnConfigExport
        '
        Me.btnConfigExport.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnConfigExport.FlatAppearance.BorderSize = 0
        Me.btnConfigExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConfigExport.Location = New System.Drawing.Point(0, -1)
        Me.btnConfigExport.Margin = New System.Windows.Forms.Padding(0)
        Me.btnConfigExport.Name = "btnConfigExport"
        Me.btnConfigExport.Size = New System.Drawing.Size(120, 30)
        Me.btnConfigExport.TabIndex = 36
        Me.btnConfigExport.Text = "Copy to clipboard"
        Me.btnConfigExport.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.btnTimelapse1)
        Me.Panel4.Controls.Add(Me.btnTimelapse12)
        Me.Panel4.Controls.Add(Me.btnTimelapse24)
        Me.Panel4.Controls.Add(Me.btnTimelapse48)
        Me.Panel4.Location = New System.Drawing.Point(27, 131)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(240, 30)
        Me.Panel4.TabIndex = 40
        '
        'btnTimelapse1
        '
        Me.btnTimelapse1.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapse1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapse1.FlatAppearance.BorderSize = 0
        Me.btnTimelapse1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapse1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapse1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapse1.Location = New System.Drawing.Point(180, 0)
        Me.btnTimelapse1.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapse1.Name = "btnTimelapse1"
        Me.btnTimelapse1.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapse1.TabIndex = 31
        Me.btnTimelapse1.Tag = "1"
        Me.btnTimelapse1.Text = "1"
        Me.btnTimelapse1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapse1.UseVisualStyleBackColor = False
        '
        'btnTimelapse12
        '
        Me.btnTimelapse12.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapse12.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapse12.FlatAppearance.BorderSize = 0
        Me.btnTimelapse12.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapse12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapse12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapse12.Location = New System.Drawing.Point(120, 0)
        Me.btnTimelapse12.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapse12.Name = "btnTimelapse12"
        Me.btnTimelapse12.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapse12.TabIndex = 30
        Me.btnTimelapse12.Tag = "12"
        Me.btnTimelapse12.Text = "12"
        Me.btnTimelapse12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapse12.UseVisualStyleBackColor = False
        '
        'btnTimelapse24
        '
        Me.btnTimelapse24.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapse24.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapse24.FlatAppearance.BorderSize = 0
        Me.btnTimelapse24.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapse24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapse24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapse24.Location = New System.Drawing.Point(60, 0)
        Me.btnTimelapse24.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapse24.Name = "btnTimelapse24"
        Me.btnTimelapse24.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapse24.TabIndex = 29
        Me.btnTimelapse24.Tag = "24"
        Me.btnTimelapse24.Text = "24"
        Me.btnTimelapse24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapse24.UseVisualStyleBackColor = False
        '
        'btnTimelapse48
        '
        Me.btnTimelapse48.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapse48.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapse48.Checked = True
        Me.btnTimelapse48.FlatAppearance.BorderSize = 0
        Me.btnTimelapse48.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapse48.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapse48.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapse48.Location = New System.Drawing.Point(0, 0)
        Me.btnTimelapse48.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapse48.Name = "btnTimelapse48"
        Me.btnTimelapse48.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapse48.TabIndex = 28
        Me.btnTimelapse48.TabStop = True
        Me.btnTimelapse48.Tag = "48"
        Me.btnTimelapse48.Text = "48"
        Me.btnTimelapse48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapse48.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnTimelapseON)
        Me.Panel3.Controls.Add(Me.btnTimelapseOFF)
        Me.Panel3.Location = New System.Drawing.Point(27, 52)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(120, 30)
        Me.Panel3.TabIndex = 39
        '
        'btnTimelapseON
        '
        Me.btnTimelapseON.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapseON.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapseON.Checked = True
        Me.btnTimelapseON.FlatAppearance.BorderSize = 0
        Me.btnTimelapseON.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapseON.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapseON.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapseON.Location = New System.Drawing.Point(0, 0)
        Me.btnTimelapseON.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapseON.Name = "btnTimelapseON"
        Me.btnTimelapseON.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapseON.TabIndex = 24
        Me.btnTimelapseON.TabStop = True
        Me.btnTimelapseON.Text = "ON"
        Me.btnTimelapseON.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapseON.UseVisualStyleBackColor = False
        '
        'btnTimelapseOFF
        '
        Me.btnTimelapseOFF.Appearance = System.Windows.Forms.Appearance.Button
        Me.btnTimelapseOFF.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnTimelapseOFF.FlatAppearance.BorderSize = 0
        Me.btnTimelapseOFF.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnTimelapseOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimelapseOFF.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimelapseOFF.Location = New System.Drawing.Point(60, 0)
        Me.btnTimelapseOFF.Margin = New System.Windows.Forms.Padding(0)
        Me.btnTimelapseOFF.Name = "btnTimelapseOFF"
        Me.btnTimelapseOFF.Size = New System.Drawing.Size(60, 30)
        Me.btnTimelapseOFF.TabIndex = 23
        Me.btnTimelapseOFF.Text = "OFF"
        Me.btnTimelapseOFF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnTimelapseOFF.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 185)
        Me.Label6.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "Current config:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(303, 27)
        Me.Label5.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(164, 13)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Start recording at camera startup:"
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Location = New System.Drawing.Point(446, 258)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(24)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(100, 35)
        Me.btnSave.TabIndex = 27
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 106)
        Me.Label3.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Images per day for Timelapse:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 27)
        Me.Label2.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Timelapse:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(303, 106)
        Me.Label1.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Recording video frame rate:"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel2.Controls.Add(Me.btnClose)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(1, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(568, 29)
        Me.Panel2.TabIndex = 25
        '
        'btnClose
        '
        Me.btnClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(538, 0)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(30, 29)
        Me.btnClose.TabIndex = 18
        Me.btnClose.Text = "❌"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(266, 447)
        Me.Label4.Margin = New System.Windows.Forms.Padding(24, 24, 24, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(138, 13)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Recording video frame rate:"
        '
        'frmConfig
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(570, 348)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label4)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmConfig"
        Me.Padding = New System.Windows.Forms.Padding(1)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Config"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnClose As Button
    Friend WithEvents btnTimelapse1 As RadioButton
    Friend WithEvents btnTimelapse12 As RadioButton
    Friend WithEvents btnTimelapse24 As RadioButton
    Friend WithEvents btnTimelapse48 As RadioButton
    Friend WithEvents btnSave As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnTimelapseON As RadioButton
    Friend WithEvents btnTimelapseOFF As RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents btnFPS1 As RadioButton
    Friend WithEvents btnFPS10 As RadioButton
    Friend WithEvents btnFPS30 As RadioButton
    Friend WithEvents btnFPS60 As RadioButton
    Friend WithEvents btnAutoStartON As RadioButton
    Friend WithEvents btnAutoStartOFF As RadioButton
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btnConfigExport As Button
    Friend WithEvents Label6 As Label
End Class
