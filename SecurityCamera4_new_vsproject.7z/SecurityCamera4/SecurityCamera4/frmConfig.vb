﻿Public Class frmConfig

    Private SelectedFPS As Integer
    Private SelectedTimelapseFPS As Integer
    Sub LoadCurrentConfig() Handles Me.Load

        btnTimelapseON.Checked = CurrentAppConfig.Timelapse
        btnTimelapseOFF.Checked = Not CurrentAppConfig.Timelapse

        btnAutoStartON.Checked = CurrentAppConfig.AutoStartRecording
        btnAutoStartOFF.Checked = Not CurrentAppConfig.AutoStartRecording

        SelectedTimelapseFPS = CurrentAppConfig.TimeLapseFPS
        btnTimelapse48.Checked = (CurrentAppConfig.TimeLapseFPS = 48)
        btnTimelapse24.Checked = (CurrentAppConfig.TimeLapseFPS = 24)
        btnTimelapse12.Checked = (CurrentAppConfig.TimeLapseFPS = 12)
        btnTimelapse1.Checked = (CurrentAppConfig.TimeLapseFPS = 1)

        SelectedFPS = CurrentAppConfig.VideoFPS
        btnFPS60.Checked = (CurrentAppConfig.VideoFPS = 60)
        btnFPS30.Checked = (CurrentAppConfig.VideoFPS = 30)
        btnFPS10.Checked = (CurrentAppConfig.VideoFPS = 10)
        btnFPS1.Checked = (CurrentAppConfig.VideoFPS = 1)

    End Sub
    Sub SetFPS(s As RadioButton, e As EventArgs) Handles btnFPS60.Click, btnFPS30.Click, btnFPS10.Click, btnFPS1.Click
        SelectedFPS = s.Tag
    End Sub
    Sub SetTimelapseFPS(s As RadioButton, e As EventArgs) Handles btnTimelapse48.Click, btnTimelapse24.Click, btnTimelapse12.Click, btnTimelapse1.Click
        SelectedTimelapseFPS = s.Tag
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Me.Close()
    End Sub

    Private Sub btnConfigExport_Click(sender As Object, e As EventArgs) Handles btnConfigExport.Click
        My.Computer.Clipboard.SetText(My.Settings.Config)
        Beep()
    End Sub

    Private Sub frmConfig_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        CurrentAppConfig.Timelapse = btnTimelapseON.Checked
        CurrentAppConfig.AutoStartRecording = btnAutoStartON.Checked
        CurrentAppConfig.VideoFPS = SelectedFPS
        CurrentAppConfig.TimeLapseFPS = SelectedTimelapseFPS
        SaveAppConfig()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class